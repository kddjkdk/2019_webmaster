﻿<form method = POST action = park_fee.php>

나이 : <input type = text name = age><P>

복지카드 : 
	<INPUT TYPE = RADIO NAME = AA VALUE = "yes">소지
	<INPUT TYPE = RADIO NAME = AA VALUE ="no"> 미소지<P>
유공자증 : 
	<INPUT TYPE = radio NAME = BA VALUE = "yes"> 소지
	<INPUT TYPE = radio NAME = BA VALUE = "no"> 미소지<P>

17:10 
	<INPUT TYPE = radio NAME = CA VALUE = "yes"> 이전
	<INPUT TYPE = radio NAME = CA VALUE = "no"> 이후<P>
	
<INPUT TYPE = "SUBMIT" VALUE= "저장">
<INPUT TYPE = "RESET" VALUE = "지우기">
</FORM>